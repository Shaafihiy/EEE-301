TODO: analog/magic
==================
