.. list-table::
   :header-rows: 2
   :stub-columns: 1


   * - Parameter
     - Stages
     - Units
     - MODEL
     - 
     - 
     - EDR
     - 
     - 

   * - 
     - 
     - 
     - TT
     - FF
     - SS
     - NOM
     - MIN
     - MAX

   * - FO = 1
     - 79
     - ps
     - 
     - 
     - 
     - 53.87
     - 46.68
     - 62.83

