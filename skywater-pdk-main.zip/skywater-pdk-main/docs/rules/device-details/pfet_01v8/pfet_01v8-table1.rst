.. list-table::
   :header-rows: 2
   :stub-columns: 1


   * - Parameter
     - Stages
     - Units
     - MODEL
     - 
     - 
     - EDR
     - 
     - 

   * - 
     - 
     - 
     - TT
     - FF
     - SS
     - NOM
     - MIN
     - MAX

   * - FO = 1
     - 143
     - ps
     - 
     - 
     - 
     - 31.8
     - 24.7
     - 44.1

