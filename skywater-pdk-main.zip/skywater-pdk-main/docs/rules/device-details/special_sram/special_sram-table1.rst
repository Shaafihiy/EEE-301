.. list-table::
   :header-rows: 2
   :stub-columns: 1


   * - Parameter
     - W/L
     - Units
     - MODEL
     - 
     - 
     - 
     - 
     - EDR
     - 
     - 

   * - 
     - 
     - 
     - TT
     - FF
     - SS
     - FS
     - SF
     - NOM
     - MIN
     - MAX

   * - VTXNLTC
     - 0.21/0.15
     - V
     - 0.715
     - 0.574
     - 0.856
     - 0.856
     - 0.575
     - 0.709
     - 0.567
     - 0.851

   * - IDSNLTC
     - 0.21/0.15
     - µA
     - 0.091
     - 0.1197
     - 0.0616
     - 0.1192
     - 0.0618
     - 87.9
     - 60.2
     - 115.5

   * - ILKNLTC
     - 0.21/0.15
     - LOG A
     - Max = -7.8
     - -9.45
     - -11.65
     - -8.90
     - 
     - 
     - 
     - 

