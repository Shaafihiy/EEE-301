.. list-table::
   :header-rows: 2
   :stub-columns: 1


   * - Parameter
     - W/L
     - Units
     - MODEL
     - 
     - 
     - 
     - 
     - EDR
     - 
     - 

   * - 
     - 
     - 
     - TT
     - FF
     - SS
     - FS
     - SF
     - NOM
     - MIN
     - MAX

   * - VTXPLTC
     - 0.14/0.15
     - V
     - -0.918
     - -0.761
     - -1.085
     - -0.747
     - -1.089
     - -0.905
     - -1.080
     - -0.732

   * - IDSPLTC
     - 0.14/0.15
     - µA
     - 0.0208
     - 0.0306
     - 0.0113
     - 0.0304
     - 0.0113
     - 19.9
     - 10.7
     - 29.1

   * - ILKPLTC
     - 0.14/0.15
     - LOG A
     - Max = -7.3
     - -9.860
     - -13.31
     - -8.880
     - 
     - 
     - 
     - 

