.. list-table::
   :header-rows: 1
   :stub-columns: 1


   * - MODEL CORNERS (\*.cor)
     - Programmed
     - Erased

   * - Beginning of Life
     - sonos\_bol\_p
     - sonos\_bol\_e

   * - End of Life
     - sonos\_eol\_p
     - sonos\_eol\_e

