.. list-table::
   :header-rows: 2
   :stub-columns: 1


   * - Parameter
     - Stages
     - Units
     - MODEL
     - 
     - 
     - EDR
     - 
     - 

   * - 
     - 
     - 
     - TT
     - FF
     - SS
     - NOM
     - MIN
     - MAX

   * - FO = 1
     - 143
     - ps
     - 
     - 
     - 
     - 28.61
     - 21.96
     - 39.15

