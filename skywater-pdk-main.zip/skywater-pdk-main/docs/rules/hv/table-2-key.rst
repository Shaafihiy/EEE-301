.. rubric:: Footnotes

.. [#f8] Resistors tagged with text ""vhv_block"" serve as VHV propagation stopper and it is the duty of the designer to ensure that the resistor can support the required voltage drop. Otherwise components in VHV nets need to be tagged with vhvi:dg layer
.. [#f9] If only source or drain is tagged with vhvi:dg layers.
