WLCSP Rules
===========

.. TODO: These should be formatted in the same way the periphery rules are.

.. csv-table:: Amkor WLCSP
   :file: wlcsp/amkor.csv
   :header-rows: 1
   :stub-columns: 1

.. csv-table:: DECA WLCSP
   :file: wlcsp/deca.csv
   :header-rows: 1
   :stub-columns: 1
