.. rubric:: Footnotes

.. [#f1] All layers drawn except pmm which is created as cpmm:mask over bond pads or converted into cpbo:mask.
.. [#f2] Entries in this table show the layer (or combination of layers) that act as connecting layers listed in the row/column headings. An X indicates that there is no direct connection between these layers. N/A is entered along the diagonal. Over is entered along layers contacted by overlapping. A layer is always connected to itself.
.. [#f3] (Met5 AND pad AND rdl) should have one of the following sizes for LVS to work with WLCSP option: 60x60, 50x70, 60x80, and 80x80
