TODO: verification/pex/calibre
==============================
