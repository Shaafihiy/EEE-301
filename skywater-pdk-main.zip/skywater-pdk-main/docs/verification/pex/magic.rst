TODO: verification/pex/magic
============================
