TODO: verification/drc/magic
============================
