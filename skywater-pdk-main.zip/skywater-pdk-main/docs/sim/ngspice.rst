TODO: sim/ngspice
=================
